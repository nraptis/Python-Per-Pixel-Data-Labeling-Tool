# main.py
import sys
import ctypes
from pathlib import Path

import glfw
import numpy as np
from OpenGL import GL as gl
from PIL import Image

from shader_program_shape_2d import ShaderProgramShape2D
from graphics_array_buffer import GraphicsArrayBuffer
from primitives import Shape2DVertex, Sprite2DVertex
from matrix import Matrix
from uniforms_shape import UniformsShapeVertex, UniformsShapeFragment
from graphics_library import GraphicsLibrary
from graphics_pipeline import GraphicsPipeline
from color import Color
from graphics_texture import GraphicsTexture

# ----------------------------------------------------------------------
# Main: Hello Triangle using your stack
# ----------------------------------------------------------------------
def main():
    # --------------------------------------------------------------
    # Initialize GLFW and create a window / context
    # --------------------------------------------------------------
    if not glfw.init():
        print("Failed to initialize GLFW")
        sys.exit(1)
        
    # OpenGL 2.1-ish is fine for this; we just need a basic context.
    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 2)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 1)

    width, height = 800, 600
    window = glfw.create_window(width, height, "Hello Shape2D (Your Stack)", None, None)
    if not window:
        glfw.terminate()
        print("Failed to create GLFW window")
        sys.exit(1)

    glfw.make_context_current(window)


    base_dir = Path(__file__).resolve().parent
    shader_path = base_dir / "shaders"
    pipeline = GraphicsPipeline(shader_path)

    image_path = base_dir / "images/image.png"

    # --------------------------------------------------------------
    # Create your GraphicsLibrary (activity/renderer/pipeline/surface_view unused)
    # --------------------------------------------------------------
    graphics = GraphicsLibrary(
        activity=None,
        renderer=None,
        pipeline=None,
        surface_view=None,
        width=width,
        height=height,
    )

    texture = GraphicsTexture(graphics=graphics, file_name=image_path)
    print("Loaded Texture: ", texture.width, ", height = ", texture.height, ", and ind = ", texture.texture_index)


    # --------------------------------------------------------------
    # Build a simple triangle using Shape2DVertex + GraphicsArrayBuffer
    # --------------------------------------------------------------
    """
    vertices = [
        Shape2DVertex(x=100.0, y=100.0),
        Shape2DVertex(x=250.0,  y=120.0),
        Shape2DVertex(x=160.0,  y=300.0),
    ]
    """

    vertices = [
        Shape2DVertex(x=-0.75, y=-0.75),
        Shape2DVertex(x=0.5,  y=-0.5),
        Shape2DVertex(x=0.5,  y=0.5),
    ]
    
    svertices = [
        Sprite2DVertex(x=-0.74, y=-0.85, u=0, v=0),
        Sprite2DVertex(x=0.65,  y=-0.55, u=1, v=1),
        Sprite2DVertex(x=0.25, y=0.9, u=0.5, v=0.5)
    ]

    vertex_buffer = GraphicsArrayBuffer[Shape2DVertex]()
    vertex_buffer.load(graphics, vertices)

    svertex_buffer = GraphicsArrayBuffer[Sprite2DVertex]()
    svertex_buffer.load(graphics, svertices)



    # Index buffer [0, 1, 2] for drawElements (uint32)
    indices = graphics.buffer_index_generate_from_list([0, 1, 2])

    # --------------------------------------------------------------
    # Set up uniforms via UniformsShapeVertex / UniformsShapeFragment
    # --------------------------------------------------------------
    # Simple identity matrices = clip-space already
    uniforms_vertex = UniformsShapeVertex(
        projection_matrix=Matrix(),  # identity by default
        model_view_matrix=Matrix(),  # identity by default
    )

    # Solid color (reddish)
    uniforms_fragment = UniformsShapeFragment(
        r=1.0,
        g=0.3,
        b=0.2,
        a=1.0,
    )
    
    print("GL VERSION:", gl.glGetString(gl.GL_VERSION))
    print("GLSL VERSION:", gl.glGetString(gl.GL_SHADING_LANGUAGE_VERSION))
    print("VENDOR:", gl.glGetString(gl.GL_VENDOR))

    err = gl.glGetError()
    if err != 0:
        print("*** GL ERROR:", hex(err))

    while not glfw.window_should_close(window):

        gl.glClearColor(1.0, 0.0, 0.0, 1.0)
        gl.glClear(gl.GL_COLOR_BUFFER_BIT)

        # Bind program + VBO + attribs
        graphics.link_buffer_to_shader_program(
            pipeline.program_sprite2d,
            svertex_buffer.buffer_index,
        )

        # Bind texture and set sampler uniform
        graphics.uniforms_texture_set_from_texture(
            pipeline.program_sprite2d,
            texture,
        )

        # ModulateColor (tint)
        loc_color = pipeline.program_sprite2d.uniform_location_modulate_color
        if loc_color != -1:
            gl.glUniform4f(loc_color, 1.0, 0.0, 1.0, 1.0)  # magenta tint

        # Draw 3 textured verts
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 3)

        graphics.unlink_buffer_from_shader_program(pipeline.program_sprite2d)

        glfw.swap_buffers(window)
        glfw.poll_events()


    glfw.terminate()


if __name__ == "__main__":
    main()
