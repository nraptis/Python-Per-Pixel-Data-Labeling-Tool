import sys
import ctypes
from pathlib import Path

import glfw
import numpy as np
from OpenGL import GL as gl
from PIL import Image

from shader_program_shape_2d import ShaderProgramShape2D
from graphics_array_buffer import GraphicsArrayBuffer
from primitives import Shape2DVertex
from matrix import Matrix
from uniforms_shape import UniformsShapeVertex, UniformsShapeFragment
from graphics_library import GraphicsLibrary

# ----------------------------------------------------------------------
# Utility: load GLSL from shaders/ folder
# ----------------------------------------------------------------------
def load_glsl(relative_path: str) -> str:
    """
    Load a GLSL file relative to this script's directory.
    e.g. 'shaders/shape_2d_vertex.glsl'
    """
    base_dir = Path(__file__).resolve().parent
    full_path = base_dir / relative_path
    with full_path.open("r", encoding="utf-8") as f:
        return f.read()


# ----------------------------------------------------------------------
# Utility: load your test image and print size
# ----------------------------------------------------------------------
def load_and_print_image_info() -> None:
    """
    Loads images/image.png and prints mode + size, using your path layout.
    """
    base_dir = Path(__file__).resolve().parent
    img_path = base_dir / "images" / "image.png"

    img = Image.open(img_path)
    print(f"Loaded image from: {img_path}")
    print(f"Image mode: {img.mode}")
    print(f"Image size: {img.width} x {img.height}")


# ----------------------------------------------------------------------
# Main: Hello Triangle using your stack
# ----------------------------------------------------------------------
def main():
    # --------------------------------------------------------------
    # Initialize GLFW and create a window / context
    # --------------------------------------------------------------
    if not glfw.init():
        print("Failed to initialize GLFW")
        sys.exit(1)

    # OpenGL 2.1-ish is fine for this; we just need a basic context.
    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 2)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 1)

    width, height = 800, 600
    window = glfw.create_window(width, height, "Hello Shape2D (Your Stack)", None, None)
    if not window:
        glfw.terminate()
        print("Failed to create GLFW window")
        sys.exit(1)

    glfw.make_context_current(window)

    # --------------------------------------------------------------
    # Quick sanity check: load your image and print info
    # --------------------------------------------------------------
    load_and_print_image_info()

    # --------------------------------------------------------------
    # Create your GraphicsLibrary (activity/renderer/pipeline/surface_view unused)
    # --------------------------------------------------------------
    graphics = GraphicsLibrary(
        activity=None,
        renderer=None,
        pipeline=None,
        surface_view=None,
        width=width,
        height=height,
    )

    # --------------------------------------------------------------
    # Load Shape2D shaders and create ShaderProgramShape2D
    # (we pass GLSL source strings to ShaderProgram)
    # --------------------------------------------------------------
    vert_src = load_glsl("shaders/shape_2d_vertex.glsl")
    frag_src = load_glsl("shaders/shape_2d_fragment.glsl")

    # NOTE: ShaderProgram in Python is implemented to compile from source strings,
    # even though the type hints say "int". We're using it with GLSL source.
    program_shape_2d = ShaderProgramShape2D(
        name="shape_2d",
        vertex_shader=vert_src,
        fragment_shader=frag_src,
    )

    # --------------------------------------------------------------
    # Build a simple triangle using Shape2DVertex + GraphicsArrayBuffer
    # --------------------------------------------------------------
    vertices = [
        Shape2DVertex(x=-0.5, y=-0.5),
        Shape2DVertex(x=0.5,  y=-0.5),
        Shape2DVertex(x=0.0,  y=0.5),
    ]

    vertex_buffer = GraphicsArrayBuffer[Shape2DVertex]()
    vertex_buffer.load(graphics, vertices)

    # Index buffer [0, 1, 2] for drawElements (uint32)
    indices = graphics.buffer_index_generate_from_list([0, 1, 2])

    # --------------------------------------------------------------
    # Set up uniforms via UniformsShapeVertex / UniformsShapeFragment
    # --------------------------------------------------------------
    # Simple identity matrices = clip-space already
    uniforms_vertex = UniformsShapeVertex(
        projection_matrix=Matrix(),  # identity by default
        model_view_matrix=Matrix(),  # identity by default
    )

    # Solid color (reddish)
    uniforms_fragment = UniformsShapeFragment(
        red=1.0,
        green=0.3,
        blue=0.2,
        alpha=1.0,
    )

    # --------------------------------------------------------------
    # Main render loop
    # --------------------------------------------------------------
    gl.glViewport(0, 0, width, height)
    gl.glClearColor(0.0, 0.0, 0.0, 1.0)

    while not glfw.window_should_close(window):
        gl.glClear(gl.GL_COLOR_BUFFER_BIT)

        # Link buffer to shader program (sets up Positions attribute)
        graphics.link_buffer_to_shader_program(program_shape_2d, vertex_buffer.buffer_index)

        # Apply vertex + fragment uniforms via your Uniforms classes
        uniforms_vertex.link(graphics, program_shape_2d)
        uniforms_fragment.link(graphics, program_shape_2d)

        # Draw the triangle using your GraphicsLibrary helper
        graphics.draw_triangles(indices, 3)

        # Clean up attribute state
        graphics.unlink_buffer_from_shader_program(program_shape_2d)

        glfw.swap_buffers(window)
        glfw.poll_events()

    glfw.terminate()


if __name__ == "__main__":
    main()
